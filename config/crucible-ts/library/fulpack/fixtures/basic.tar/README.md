# Basic TAR Fixture

Uncompressed tar archive for testing tar format operations.

## Contents
- 4 text files (README, config, metadata, sample)
- 1 binary file (small PNG-like binary blob)
- 2 directories (root, data/)
- Total uncompressed: ~600 bytes

## Purpose
- Verify tar format create/extract operations
- Test compression_ratio = 1.0 (no compression)
- Verify binary data integrity (PNG blob)
- Performance baseline (fastest format, no compression overhead)

## Expected Behavior
- create(): compression_level ignored, ratio = 1.0
- extract(): Fastest extraction (no decompression)
- scan(): Fastest TOC read
- info(): compressed_size = total_size
- verify(): No bomb detection from ratio, but enforce max_size/max_entries
