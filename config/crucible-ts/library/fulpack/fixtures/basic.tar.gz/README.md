# Basic TAR.GZ Fixture

Compressed tar archive for standard testing.

## Contents
5 small text files demonstrating compression.
