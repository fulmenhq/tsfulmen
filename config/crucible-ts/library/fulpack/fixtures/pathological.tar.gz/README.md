# Pathological Archive - Security Test Cases

This archive contains malicious path patterns for testing security protections.
DO NOT extract without security validation!

## Malicious Patterns
1. Path traversal attempts (../../../etc/passwd)
2. Absolute paths (/etc/passwd, /root/.ssh/id_rsa)
3. Symlink escape attempts (symlinks targeting outside archive)

All operations MUST validate paths before extraction.
