# Pathological Archive
This archive contains path traversal attempts and should be rejected by security validation.

Contents:
- safe.txt: Normal file
- ..traversal.txt: File with .. in name
- Files with paths that attempt directory traversal

Expected behavior: Extract/scan operations should detect and reject traversal attempts.
